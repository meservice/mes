  import 'dart:io';
  import 'package:flutter/material.dart';
  import 'package:splash_screen_view/SplashScreenView.dart';
  
  
  
  
  import 'package:myapp/src/pages/entrypoint/page.dart';
  import 'package:teta_cms/teta_cms.dart';

  ///NOTE:
  ///if you have an error while running <flutter run> 
  ///run <flutter pub upgrade> and than <flutter run --no-sound-null-safety>
  void main() async {
    WidgetsFlutterBinding.ensureInitialized();
    await TetaCMS.initialize(
      token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im1vbmRhbGVzZXJ2aWNlMjAyMEBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwicHJvamVjdHMiOlsxMjI3MDRdLCJpbWFnZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hLS9BT2gxNEdqUzlfNHFGbzdLdnBIUXk5WExGb0xnT2xTYzEzODdJaWVHMEotaj1zOTYtYyIsIm5hbWUiOiJNb25kYWwgZS1TZXJ2aWNlIiwiZW1pdHRlciI6IlRldGEtQXV0aCIsImlhdCI6MTY1MzU0MjYwNCwiZXhwIjo0ODA5MzAyNjA0fQ.yFYPJp-9dmAupO4yrHnaWuyvQU_PPxHFg5GRH16j8l8',
      prjId: 122704,
    );
    
    
    
    
    runApp(
      MyApp()
    );
  }
  class MyApp extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
      return MaterialApp(
        title: 'Untitled',
        home: SplashScreenView(
          navigateRoute: PageEntryPoint(),
          duration: 2200,
          imageSize: 80,
          imageSrc: 'assets/teta-app.png',
          text: '',
          textType: TextType.NormalText,
          textStyle: TextStyle(
            fontSize: 30.0,
          ),
          backgroundColor: Colors.black,
        ),
      );
    }
  }
  